def near_ten(num):
  tmp = num % 10
  return tmp <= 2 or tmp >= 8
