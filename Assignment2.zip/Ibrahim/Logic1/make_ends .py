def make_ends(nums):
  lst = [nums[0], nums[len(nums)-1]]
  return lst
