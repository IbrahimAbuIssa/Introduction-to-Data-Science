def sorta_sum(a, b):
  sum = a + b
  if (sum >= 10 and sum < 20):
    return 20
  return sum
