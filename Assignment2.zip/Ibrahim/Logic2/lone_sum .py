def lone_sum(a, b, c):
  if a == b and b == c:
    return 0
  if a == b:
    return c
  elif b == c:
    return a
  elif a == c:
    return b
  else:
    return a + b + c
