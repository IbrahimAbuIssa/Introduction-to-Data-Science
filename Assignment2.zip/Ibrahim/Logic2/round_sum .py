def round_sum(a, b, c):
  return round10(a) + round10(b) + round10(c)
  
def round10(n):
  tmp = n % 10
  if tmp < 5:
    return n-tmp
  return n + 10-tmp
