def lucky_sum(a, b, c):
  sum = 0
  if a == 13:
    return sum
  sum += a
  if b == 13:
    return sum
  sum += b
  if c == 13:
    return sum
  return sum + c
