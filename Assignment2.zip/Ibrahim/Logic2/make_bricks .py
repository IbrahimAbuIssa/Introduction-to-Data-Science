def make_bricks(small, big, goal):
  bg = goal/5
  tmp = min(bg, big)
  goal -= 5 * tmp
  if small >= goal:
    return True
  return False
  
