def make_chocolate(small, big, goal):
  tmp = goal/5
  big = min(tmp, big)
  goal -= 5*big
  if small >= goal:
    return goal
  return -1
