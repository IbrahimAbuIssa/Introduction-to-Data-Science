def cat_dog(str):
  cntD = 0
  cntC = 0
  for i in range (len(str)-2):
    if str[i:i+3] == "dog":
      cntD = cntD + 1
    elif str[i:i+3] == "cat":
      cntC = cntC + 1
  return cntC == cntD
