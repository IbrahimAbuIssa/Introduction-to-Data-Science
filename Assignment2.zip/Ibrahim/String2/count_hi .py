def count_hi(str):
  return str.count('hi')
