def double_char(str):
  tmp = ""
  for i in range(len(str)):
    tmp = tmp + str[i] + str[i]
  return tmp
