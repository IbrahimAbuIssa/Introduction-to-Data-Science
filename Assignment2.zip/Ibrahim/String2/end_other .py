def end_other(a, b):
  a = a.lower()
  b = b.lower()
  siz = len(b)-1
  for i in range(len(a)-1, -1, -1):
    if siz < 0:
      return True
    if a[i] != b[siz]:
      return False
    siz = siz-1  
  return True
