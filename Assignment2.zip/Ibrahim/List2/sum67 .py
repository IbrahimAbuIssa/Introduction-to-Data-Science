def sum67(nums):
  sum = 0
  b = False
  for i in range (len(nums)):
    if nums[i] == 6:
      b = True
    if b == True and nums[i] == 7:
      b = False
      continue
    if not b:
      sum += nums[i]
  return sum