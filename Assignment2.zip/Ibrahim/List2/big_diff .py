def big_diff(nums):
  mn = nums[0]
  mx = nums[0]
  for i in range (len(nums)):
    if nums[i] < mn:
      mn = nums[i]
    if nums[i] > mx:
      mx = nums[i]
  return mx - mn
