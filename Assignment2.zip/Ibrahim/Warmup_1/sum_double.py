def sum_double(a, b):
  if a == b:
    a *= 2
    b *= 2
  return a + b
