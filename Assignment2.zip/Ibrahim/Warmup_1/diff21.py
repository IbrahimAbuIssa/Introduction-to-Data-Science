def diff21(n):
  if n >= 21:
    return (n-21)*2
  return 21-n
