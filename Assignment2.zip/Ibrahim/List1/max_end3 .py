def max_end3(nums):
  siz = len(nums)
  mx = nums[0]
  if nums[siz-1] > mx:
    mx = nums[siz-1]
  nums[0] = nums[1] = nums[2] = mx
  return nums
