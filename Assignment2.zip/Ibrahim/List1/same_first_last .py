def same_first_last(nums):
  siz = len(nums)
  if siz >= 1 and nums[0] == nums[siz-1]:
    return True
  return False
