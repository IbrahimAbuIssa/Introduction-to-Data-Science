def reverse3(nums):
  siz = len(nums)
  for i in range(siz/2):
    tmp = nums[i]
    nums[i] = nums[siz-i-1]
    nums[siz-i-1] = tmp
  return nums
    
