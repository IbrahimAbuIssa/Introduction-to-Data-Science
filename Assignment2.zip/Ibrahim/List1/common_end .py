def common_end(a, b):
  if a[0] == b[0] or b[len(b)-1] == a[len(a)-1]:
    return True
  return False
