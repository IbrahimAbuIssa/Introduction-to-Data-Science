def first_last6(nums):
  siz = len(nums)-1
  if nums[0] == 6 or nums[siz] == 6:
    return True
  return False
