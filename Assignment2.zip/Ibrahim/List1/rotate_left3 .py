def rotate_left3(nums):
  lst = nums[:]
  nums[0] = lst[1]
  nums[1] = lst[2]
  nums[2] = lst[0]
  return nums
