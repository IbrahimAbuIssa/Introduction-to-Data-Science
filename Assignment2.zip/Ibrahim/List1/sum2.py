def sum2(nums):
  sum = 0
  for i in range(len(nums)):
    if i > 1:
      break
    sum = sum + nums[i]
  return sum
