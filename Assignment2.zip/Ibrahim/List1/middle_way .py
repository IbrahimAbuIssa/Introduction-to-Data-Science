def middle_way(a, b):
  lst = [a[1], b[1]]
  return lst
