def string_times(str, n):
  tmp = ""
  for i in range(n):
    tmp = tmp + str
  return tmp
