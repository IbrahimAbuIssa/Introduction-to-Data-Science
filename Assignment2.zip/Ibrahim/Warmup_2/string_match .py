def string_match(a, b):
  cnt = 0
  siz = len(a)
  if len(b) < siz:
    siz = len(b)
  for i in range(siz-1):
    if a[i] == b[i] and a[i+1] == b[i+1]:
      cnt = cnt+1
  return cnt
