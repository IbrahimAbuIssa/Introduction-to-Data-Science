def front_times(str, n):
  tmp = ""
  if len(str) < 3:
    for i in range(n):
      tmp = tmp + str
  else:
    for i in range(n):
      tmp = tmp + str[:3]
  return tmp
