def string_splosion(str):
  tmp = ""
  for i in range(1, len(str)+1):
    tmp = tmp + str[:i]
  return tmp
