def last2(str):
  cnt = 0
  siz = len(str)
  if siz < 4:
    return cnt
  tmp = str[siz-2:]
  for i in range(siz-2):
    if str[i:i+2] == tmp:
      cnt = cnt + 1
  return cnt
    
