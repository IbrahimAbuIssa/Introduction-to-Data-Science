def string_bits(str):
  tmp = ""
  for i in range(len(str)):
    if i % 2 == 0:
      tmp = tmp + str[i]
  return tmp
