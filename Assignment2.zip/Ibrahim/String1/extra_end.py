def extra_end(str):
  siz = len(str)
  return str[siz-2:] + str[siz-2:] + str[siz-2:]
