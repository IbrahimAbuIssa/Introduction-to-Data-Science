def combo_string(a, b):
  siza = len(a)
  sizb = len(b)
  if(siza < sizb):
    return a + b + a
  else:
    return b + a + b
